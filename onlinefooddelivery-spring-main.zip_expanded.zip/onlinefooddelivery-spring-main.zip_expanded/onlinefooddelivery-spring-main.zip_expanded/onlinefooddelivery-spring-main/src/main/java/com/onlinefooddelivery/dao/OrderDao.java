package com.onlinefooddelivery.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlinefooddelivery.modal.Order;

public interface OrderDao extends JpaRepository<Order, Long> {

}
