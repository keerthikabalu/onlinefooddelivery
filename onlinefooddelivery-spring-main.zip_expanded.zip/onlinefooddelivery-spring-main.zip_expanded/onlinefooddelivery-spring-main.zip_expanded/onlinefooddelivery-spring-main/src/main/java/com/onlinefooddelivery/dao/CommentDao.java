package com.onlinefooddelivery.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlinefooddelivery.modal.Comment;

public interface CommentDao extends JpaRepository<Comment, Long> {

}
