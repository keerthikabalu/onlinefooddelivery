package com.onlinefooddelivery.modal;

public enum OrderStatus {
	PAID
}
