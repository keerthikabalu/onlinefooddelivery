package com.onlinefooddelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnileFoodDeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
